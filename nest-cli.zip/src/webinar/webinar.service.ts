import {
  BadRequestException,
  forwardRef,
  Inject,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model, PipelineStage, Types } from 'mongoose';
import { Webinar } from 'src/schemas/Webinar.schema';
import { CreateWebinarDto, UpdateWebinarDto } from './dto/createWebinar.dto';
import { AttendeesService } from 'src/attendees/attendees.service';
import { WebinarFilterDTO } from './dto/webinar-filter.dto';
import { NotificationService } from 'src/notification/notification.service';
import {
  notificationActionType,
  notificationType,
} from 'src/schemas/notification.schema';
import { AssignmentService } from 'src/assignment/assignment.service';
import { NotesService } from 'src/notes/notes.service';
import { AlarmService } from 'src/alarm/alarm.service';
import { EnrollmentsService } from 'src/enrollments/enrollments.service';
import { Logger } from '@nestjs/common';
import { SubscriptionService } from 'src/subscription/subscription.service';

@Injectable()
export class WebinarService {
  private readonly logger = new Logger(WebinarService.name);

  constructor(
    @InjectModel(Webinar.name) private webinarModel: Model<Webinar>,
    @Inject(forwardRef(() => AttendeesService))
    private readonly attendeesService: AttendeesService,
    private readonly notificationService: NotificationService,
    @Inject(forwardRef(() => NotesService))
    private readonly notesService: NotesService,
    @Inject(forwardRef(() => AlarmService))
    private readonly alarmService: AlarmService,
    @Inject(forwardRef(() => AssignmentService))
    private readonly assignmentService: AssignmentService,
    private readonly enrollmentService: EnrollmentsService,
    @Inject(forwardRef(() => SubscriptionService))
    private readonly subscriptionService: SubscriptionService,
  ) {}

  async createWebiar(createWebinarDto: CreateWebinarDto): Promise<any> {
    // Create webinar
    console.log(createWebinarDto);

    const result = await this.webinarModel.create(createWebinarDto);

    if (result) {
      createWebinarDto.assignedEmployees.forEach(async (employeeId) => {
        // Create a notification for each assigned employee
        await this.notificationService.createNotification({
          recipient: `${employeeId}`,
          title: 'New Webinar Assigned',
          message: `You have been assigned to a new webinar: ${createWebinarDto.webinarName}`,
          type: notificationType.INFO,
          actionType: notificationActionType.WEBINAR_ASSIGNMENT,
          metadata: {
            webinarId: result._id,
            webinarTitle: createWebinarDto.webinarName,
          },
        });
      });
    }

    return result;
  }

  async getWebinars(
    adminId: string,
    page: number,
    limit: number,
    filters: WebinarFilterDTO = {},
    usePagination: boolean = true, // Flag to enable/disable pagination
  ): Promise<any> {
    console.log('limterr-r ===> ', limit);

    const skip = (page - 1) * limit;

    const query = { adminId: new Types.ObjectId(`${adminId}`) };

    const dateFilter: any = {};
    if (filters.webinarDate) {
      dateFilter['webinarDate'] = {};
      if (filters.webinarDate.$gte) {
        dateFilter['webinarDate']['$gte'] = new Date(filters.webinarDate.$gte);
      }
      if (filters.webinarDate.$lte) {
        dateFilter['webinarDate']['$lte'] = new Date(filters.webinarDate.$lte);
      }
    }

    // Base pipeline used for both cases
    const basePipeline: PipelineStage[] = [
      {
        $match: query,
      },
      {
        $match: {
          ...(filters.webinarName && {
            webinarName: { $regex: filters.webinarName, $options: 'i' },
          }),
          ...dateFilter,
          ...(Array.isArray(filters.assignedEmployee) &&
            filters.assignedEmployee.length > 0 && {
              assignedEmployees: {
                $in: filters.assignedEmployee.map(
                  (item) => new Types.ObjectId(item),
                ),
              },
            }),
        },
      },
      {
        $lookup: {
          from: 'attendees',
          localField: '_id',
          foreignField: 'webinar',
          as: 'attendees',
        },
      },
      {
        $project: {
          _id: 1,
          webinarName: 1,
          webinarDate: 1,
          assignedEmployees: 1,
          adminId: 1,
          createdAt: 1,
          updatedAt: 1,
          totalAttendees: {
            $size: {
              $filter: {
                input: '$attendees',
                as: 'attendee',
                cond: {
                  $and: [
                    { $eq: ['$$attendee.isAttended', true] },
                    { $gt: ['$$attendee.timeInSession', 0] },
                    { $ne: ['$$attendee.isDeleted', true] },
                  ],
                },
              },
            },
          },
          totalRegistrations: {
            $size: {
              $filter: {
                input: '$attendees',
                as: 'attendee',
                cond: {
                  $and: [
                    { $eq: ['$$attendee.isAttended', false] },
                    { $ne: ['$$attendee.isDeleted', true] },
                  ],
                },
              },
            },
          },

          totalParticipants: {
            $size: {
              $filter: {
                input: '$attendees',
                as: 'attendee',
                cond: {
                  $and: [
                    { $eq: ['$$attendee.isAttended', true] },
                    { $ne: ['$$attendee.isDeleted', true] },
                  ],
                },
              },
            },
          },
          productIds: 1,
        },
      },
      {
        $addFields: {
          totalUnAttended: {
            $subtract: ['$totalParticipants', '$totalAttendees'],
          },
        },
      },
      {
        $match: {
          ...(filters.totalRegistrations && {
            totalRegistrations: filters.totalRegistrations,
          }),
          ...(filters.totalAttendees && {
            totalAttendees: filters.totalAttendees,
          }),
          ...(filters.totalParticipants && {
            totalParticipants: filters.totalParticipants,
          }),
          ...(filters.totalUnAttended && {
            totalUnAttended: filters.totalUnAttended,
          }),
        },
      },
      {
        $sort: {
          createdAt: -1, // Sort by createdAt in descending order
        },
      },
    ];

    if (usePagination) {
      // Add $facet stage for pagination
      basePipeline.push(
        {
          $facet: {
            metadata: [{ $count: 'total' }],
            data: [{ $skip: skip }, { $limit: limit }],
          },
        },
        {
          $unwind: {
            path: '$metadata',
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $project: {
            pagination: {
              totalPages: { $ceil: { $divide: ['$metadata.total', limit] } },
              page: { $literal: page },
              total: '$metadata.total',
              limit: { $literal: limit },
            },
            result: '$data',
          },
        },
      );

      const result = await this.webinarModel.aggregate(basePipeline);
      return result.length > 0
        ? result[0]
        : {
            result: [],
            pagination: { totalPages: 0, page: 1, total: 0, limit: limit },
          };
    } else {
      // Add skip and limit directly for consistent output without $facet
      basePipeline.push({ $skip: skip }, ...(limit ? [{ $limit: limit }] : []));

      const result = await this.webinarModel.aggregate(basePipeline);
      return {
        result, // Return all data
        page: 1, // Fixed page
        totalPages: 1, // No pagination
      };
    }
  }

  async getWebinar(id: string, adminId: string): Promise<any> {
    const result = await this.webinarModel
      .findOne({
        _id: new Types.ObjectId(`${id}`),
        adminId: new Types.ObjectId(`${adminId}`),
      })
      .populate('assignedEmployees')
      .populate('productIds')
      .lean();
    return result;
  }

  async updateWebinar(
    id: string,
    adminId: string,
    updateWebinarDto: UpdateWebinarDto,
  ): Promise<any> {
    const webinar = await this.webinarModel.findById(id);

    if (!webinar) {
      throw new NotFoundException('Webinar not found');
    }

    const previousAssigned = webinar.assignedEmployees || [];
    const updatedAssigned: any = updateWebinarDto.assignedEmployees || [];

    // Identify removed employees
    const removedEmployees = previousAssigned.filter(
      (empId: Types.ObjectId) => !updatedAssigned.includes(`${empId}`),
    );

    // If there are removed employees, check if they're assigned elsewhere
    if (removedEmployees.length > 0) {
      const isAssignmentExists =
        await this.assignmentService.checkAssignmentExists(
          removedEmployees,
          new Types.ObjectId(`${id}`),
        );

      if (isAssignmentExists) {
        throw new BadRequestException(
          'One or more removed employees are still assigned to another task',
        );
      }
    }

    // Proceed with the update
    const result = await this.webinarModel.findOneAndUpdate(
      {
        _id: new Types.ObjectId(id),
        adminId: new Types.ObjectId(adminId),
      },
      {
        $set: {
          ...updateWebinarDto,
        },
      },
      { new: true }, // return the updated document
    );

    return result;
  }

  async deleteWebinar(id: string, admin: string): Promise<any> {
    const webinarId = new Types.ObjectId(`${id}`);
    const adminId = new Types.ObjectId(`${admin}`);
    const session = await this.webinarModel.startSession();

    try {
      await session.withTransaction(async (currentSession) => {
        // Delete webinar
        const deletedWebinar = await this.webinarModel
          .findOneAndDelete({
            _id: webinarId,
            adminId: new Types.ObjectId(adminId),
          })
          .session(currentSession);

        if (!deletedWebinar) {
          throw new NotFoundException('Webinar not found');
        }

        const attendees: any =
          await this.attendeesService.getAttendeeForDeletion(
            webinarId,
            currentSession,
          );
        const attendeeIds = attendees.map((a) => a._id);

        // Configure deletion workflow
        await this.alarmService.deleteAlarmsByAttendeeIds(
          currentSession,
          attendeeIds,
        );

        await this.assignmentService.deleteAssignmentsByWebinar(
          currentSession,
          adminId,
          webinarId,
        );

        await this.attendeesService.deleteAttendeesByWebinar(
          currentSession,
          webinarId,
          adminId,
        );

        await this.enrollmentService.deleteEnrollmentsByWebinar(
          currentSession,
          adminId,
          webinarId,
        );

        await this.notesService.deleteNotesByAttendees(
          currentSession,
          attendeeIds,
        );

        await this.notificationService.deleteNotificationsByWebinar(
          currentSession,
          webinarId,
        );

        const contactCount =
          await this.attendeesService.getNonUniqueAttendeesCount(
            [],
            adminId,
            currentSession,
          );

        await this.subscriptionService.updateContactCount(
          adminId,
          contactCount,
          currentSession,
        );

        return { message: 'Webinar deleted successfully' };
      });
    } catch (error) {
      console.error('Transaction failed during hideAttendees:', error);
      throw new BadRequestException(error.message);
    } finally {
      await session.endSession();
      console.log('Session ended.');
    }
  }

  async getEmployeeWebinars(
    employeeId: string,
    adminId: string,
  ): Promise<Webinar[]> {
    const result = await this.webinarModel
      .find({
        assignedEmployees: { $in: [new Types.ObjectId(`${employeeId}`)] },
        adminId: new Types.ObjectId(`${adminId}`),
      })
      .sort({ createdAt: -1 });
    return result;
  }

  async getAssignedEmployees(webinarId: string): Promise<any> {
    const result: any = await this.webinarModel
      .findById(webinarId)
      .populate('assignedEmployees')
      .lean();

    if (!result || !Array.isArray(result.assignedEmployees)) return [];

    return (
      result.assignedEmployees.filter((employee) => employee?.isActive) || []
    );
  }

  async getWebinarById(webinarId: string): Promise<Webinar> {
    return this.webinarModel.findById(webinarId);
  }

  async getAssignedProducts(webinarId: Types.ObjectId) {
    return this.webinarModel.findById(webinarId).populate('productIds');
  }

  async updateAssignedEmployees(
    webinarId: Types.ObjectId,
    tempEmployees: Types.ObjectId[],
  ) {
    await this.webinarModel.findByIdAndUpdate(
      webinarId,
      { $set: { assignedEmployees: tempEmployees } },
      { new: true },
    );
  }
}
