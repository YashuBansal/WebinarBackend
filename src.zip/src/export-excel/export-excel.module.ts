import { MiddlewareConsumer, Module, RequestMethod } from '@nestjs/common';
import { ExportExcelController } from './export-excel.controller';
import { ExportExcelService } from './export-excel.service';
import { MongooseModule } from '@nestjs/mongoose';
import { UsersModule } from 'src/users/users.module';
import { AttendeesModule } from 'src/attendees/attendees.module';
import { ValidateBodyFilters } from 'src/middlewares/validate-body-filters.Middleware';
import { SubscriptionModule } from 'src/subscription/subscription.module';
import { WebinarModule } from 'src/webinar/webinar.module';
import { AuthAdminTokenMiddleware } from 'src/middlewares/authAdmin.Middleware';
import {
  UserDocuments,
  UserDocumentsSchema,
} from 'src/schemas/user-documents.schema';
import { CustomLeadTypeModule } from 'src/custom-lead-type/custom-lead-type.module';
import { AuthSuperAdminMiddleware } from 'src/middlewares/authSuperAdmin.Middleware';
import { UserActivityModule } from 'src/user-activity/user-activity.module';
import { AssignmentModule } from 'src/assignment/assignment.module';
import { WebsocketModule } from 'src/websocket/websocket.module';
import { BillingHistoryModule } from 'src/billing-history/billing-history.module';
import { ProductRevenueModule } from 'src/product-revenue/product-revenue.module';
import { EnrollmentsModule } from 'src/enrollments/enrollments.module';

@Module({
  imports: [
    MongooseModule.forFeature([
      { name: UserDocuments.name, schema: UserDocumentsSchema },
    ]),
    UsersModule,
    SubscriptionModule,
    WebinarModule,
    AttendeesModule,
    CustomLeadTypeModule,
    UserActivityModule,
    AssignmentModule,
    WebsocketModule,
    BillingHistoryModule,
    ProductRevenueModule,
    EnrollmentsModule,
  ],
  controllers: [ExportExcelController],
  providers: [ExportExcelService],
  exports: [ExportExcelService],
})
export class ExportExcelModule {
  configure(consumer: MiddlewareConsumer) {
    consumer.apply(AuthAdminTokenMiddleware, ValidateBodyFilters).forRoutes(
      {
        path: 'export-excel/webinar-attendees',
        method: RequestMethod.POST,
      },
      {
        path: 'export-excel/employee-assignments/:empId',
        method: RequestMethod.POST,
      },
      {
        path: 'export-excel/attendees',
        method: RequestMethod.POST,
      },
    );
    consumer.apply(AuthAdminTokenMiddleware).forRoutes(
      { path: 'export-excel/webinars', method: RequestMethod.POST },
      {
        path: 'export-excel/user-activity/:userId',
        method: RequestMethod.POST,
      },
      {
        path: 'export-excel/product-revenue',
        method: RequestMethod.POST,
      },
      {
        path: 'export-excel/employees',
        method: RequestMethod.POST,
      },
      {
        path: 'export-excel/enrollments',
        method: RequestMethod.POST,
      },
      { path: 'export-excel/user-documents', method: RequestMethod.GET },
      { path: 'export-excel/user-documents/:id', method: RequestMethod.GET },
      { path: 'export-excel/user-documents/:id', method: RequestMethod.DELETE },
    );
    consumer
      .apply(AuthSuperAdminMiddleware)
      .forRoutes(
        { path: 'export-excel/client', method: RequestMethod.POST },
        { path: 'export-excel/client-billing', method: RequestMethod.POST },
      );
  }
}
