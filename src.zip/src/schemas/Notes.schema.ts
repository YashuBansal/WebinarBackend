import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document, Types } from 'mongoose';
import { Attendee } from './Attendee.schema';
import { User } from './User.schema';
import { Webinar } from './Webinar.schema';

@Schema({ timestamps: true })
export class Notes extends Document {
  @Prop({
    type: Types.ObjectId,
    ref: User.name,
    required: [true, 'Admin id is required'],
  })
  adminId: Types.ObjectId;

  @Prop({
    type: Types.ObjectId,
    ref: Webinar.name,
    required: [true, 'Webinar id is required'],
  })
  webinarId: Types.ObjectId;

  @Prop({
    type: Types.ObjectId,
    ref: Attendee.name,
    required: [true, 'Attendee ID is required'],
  })
  attendee: Types.ObjectId;

  @Prop({
    type: String,
    required: [true, 'E-Mail is required'],
    trim: true,
  })
  email: string;

  @Prop({
    type: String,
    required: false,
  })
  note: string;

  @Prop({
    type: String,
    required: [true, 'Phone number is required'],
    default: null,
    trim: true,
  })
  phone: string;

  @Prop({
    type: Number,
    default: 0,
    min: 0,
  })
  callDuration: number;

  @Prop({
    type: String,
    required: [true, 'status is required'],
  })
  status: string;

  @Prop({
    type: [],
    required: false,
  })
  image: string[];

  @Prop({
    type: Types.ObjectId,
    ref: User.name,
    required: [true, 'created by id is required'],
  })
  createdBy: Types.ObjectId;

  @Prop({
    type: Boolean,
    default: false,
  })
  isWorked: boolean;

  @Prop({
    type: Boolean,
  })
  isInvalidPhone: boolean;

  @Prop({
    type: Date,
  })
  assignmentDate: Date;
}

export const NotesSchema = SchemaFactory.createForClass(Notes);
NotesSchema.index({ attendee: 1 });

NotesSchema.pre('save', function (next) {
  if (typeof this.createdBy === 'string') {
    this.createdBy = new Types.ObjectId(`${this.createdBy}`);
  }
  if (typeof this.attendee === 'string') {
    this.attendee = new Types.ObjectId(`${this.attendee}`);
  }
  if (typeof this.webinarId === 'string') {
    this.webinarId = new Types.ObjectId(`${this.webinarId}`);
  }
  next();
});
