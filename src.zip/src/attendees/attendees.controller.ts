import {
  BadRequestException,
  Body,
  Controller,
  Delete,
  forwardRef,
  Get,
  Inject,
  NotAcceptableException,
  NotFoundException,
  Param,
  Patch,
  Post,
  Put,
  Query,
} from '@nestjs/common';
import { AdminId, Id } from 'src/decorators/custom.decorator';
import { AttendeesService } from './attendees.service';
import {
  DeleteAllAttendeesDTO,
  DeleteWebinarAttendeesDTO,
  FetchGroupedAttendeesDTO,
  FetchGroupedAttendeesForAPIDTO,
  GetAttendeesDTO,
  ImportAttendeesDTO,
  SwapAttendeeFieldsDTO,
  UpdateAttendeeDto,
  UpdateAttendeeTagDTO,
} from './dto/attendees.dto';
import mongoose, { Types } from 'mongoose';
import { WebinarService } from 'src/webinar/webinar.service';
import { AssignmentService } from 'src/assignment/assignment.service';
import { WebinarParticipantService } from 'src/webinar-participant/webinar-participant.service';

@Controller('attendees')
export class AttendeesController {
  constructor(
    private readonly attendeesService: AttendeesService,
    private readonly assignService: AssignmentService,
    @Inject(forwardRef(() => WebinarService))
    private readonly webinarService: WebinarService,
    private readonly webinarParticipantService: WebinarParticipantService,
  ) {}

  @Get('webinar')
  async getAttendees(@Id() adminId: string, @Query() query: GetAttendeesDTO) {
    const start = Date.now();
    const page = Number(query?.page) > 0 ? Number(query?.page) : 1;
    const limit = Number(query?.limit) > 0 ? Number(query?.limit) : 25;
    const result = await this.attendeesService.getAttendees(
      query.webinarId || '',
      adminId,
      query.isAttended === 'true',
      page,
      limit,
      {
        filters: query.filters,
        validCall: query?.validCall,
        assignmentType: query?.assignmentType,
        sort: query?.sort,
        leadType: query?.leadType === 'true',
        fields: query.fields,
      },
    );

    const processingTime = Date.now() - start;
    console.log(`Processing time: ${processingTime} milliseconds`);
    return result ? { ...result, processingTime } : result;
  }

  @Get('invalid-tags')
  async getInvalidTags(@Id() adminId: string) {
    if (mongoose.isValidObjectId(adminId)) {
      const data = await this.attendeesService.getInvalidTags(
        new Types.ObjectId(`${adminId}`),
      );

      return {
        success: true,
        data,
      };
    }
    throw new BadRequestException('Invalid Admin ID');
  }

  @Get('webinar-participants/:id')
  async getWebinar(@Id() adminId: string, @Param('id') webinarId: string) {
    if (
      !mongoose.isValidObjectId(adminId) ||
      !mongoose.isValidObjectId(webinarId)
    ) {
      throw new NotFoundException('Admin Id and Webinar Id is Required');
    }
    return await this.webinarParticipantService.findByAdminAndWebinar(
      new Types.ObjectId(`${adminId}`),
      new Types.ObjectId(webinarId),
    );
  }

  @Get('grouped')
  async fechtGroupedAttendeesForAPI(
    @Query() query: FetchGroupedAttendeesForAPIDTO,
    @Id() adminId: string,
  ) {
    const start = Date.now();
    const page = Number(query?.page) > 0 ? Number(query?.page) : 1;
    const limit = Number(query?.limit) > 0 ? Number(query?.limit) : 25;
    console.log('im here', query);
    const result = await this.attendeesService.fetchGroupedAttendees(
      new Types.ObjectId(`${adminId}`),
      page,
      limit,
      query.filters,
      query.sort,
    );
    const processingTime = Date.now() - start;
    console.log(`Processing time: ${processingTime} milliseconds`);
    return { ...result, processingTime };
  }

  @Get(':email')
  async getAttendee(
    @Param('email') email: string,
    @AdminId() adminId: string,
  ): Promise<any> {
    const result = await this.attendeesService.getAttendee(adminId, email);
    return result;
  }

  @Post('grouped')
  async fechtGroupedAttendees(
    @Query() query: { page?: string; limit?: string },
    @Id() adminId: string,
    @Body() body: FetchGroupedAttendeesDTO,
  ) {
    const start = Date.now();
    const page = Number(query?.page) > 0 ? Number(query?.page) : 1;
    const limit = Number(query?.limit) > 0 ? Number(query?.limit) : 25;
    const result = await this.attendeesService.fetchGroupedAttendees(
      new Types.ObjectId(`${adminId}`),
      page,
      limit,
      body.filters,
      body.sort,
    );
    const processingTime = Date.now() - start;
    console.log(`Processing time: ${processingTime} milliseconds`);
    return { ...result, processingTime };
  }

  @Put('tag')
  async updateAttendeeTag(
    @Id() adminId: string,
    @Body() body: UpdateAttendeeTagDTO,
  ) {
    return await this.attendeesService.updateAttendeeTags(
      new Types.ObjectId(`${adminId}`),
      new Types.ObjectId(`${body.webinar}`),
      body.emails,
      body.tag,
    );
  }

  @Post()
  async addPostAttendees(
    @Id() adminId: string,
    @Body()
    body: ImportAttendeesDTO,
  ): Promise<any> {
    const webinar = await this.webinarService.getWebinar(
      body.webinarId,
      adminId,
    );

    if (!webinar) {
      throw new NotFoundException('Webinar not found.');
    }

    const data = body.data;
    const postWebinarExists =
      await this.attendeesService.getPostWebinarAttendee(
        body.webinarId,
        adminId,
      );  

    if (postWebinarExists && !body.isAttended) {
      throw new NotAcceptableException(
        'Cannot add Pre-Webinar data as it already exists in Post-Webinar.',
      );
    }

    for (let i = 0; i < data.length; i++) {
      data[i].webinar = new Types.ObjectId(`${body.webinarId}`);
      data[i].isAttended = body.isAttended;
      data[i].adminId = new Types.ObjectId(`${adminId}`);
      data[i].email = (data[i].email || '').toLowerCase();
      data[i].phone = this.assignService.formatPhoneNumber(data[i].phone) || '';
    }

    const result = await this.attendeesService.addPostAttendees(
      data,
      body.webinarId,
      body.isAttended,
      adminId,
      postWebinarExists ? true : false,
      webinar.webinarName,
      body.unMergedData,
    );
    return result;
  }

  @Patch(':id')
  async updateAttendee(
    @Param('id') id: string,
    @Body() updateAttendeeDto: UpdateAttendeeDto,
    @AdminId() adminId: string,
    @Id() userId: string,
  ): Promise<any> {
    const result = await this.attendeesService.updateAttendee(
      id,
      adminId,
      userId,
      updateAttendeeDto,
    );
    return result;
  }

  @Put('/swap')
  async swapAttendees(
    @Body() body: SwapAttendeeFieldsDTO,
    @Id() adminId: string,
  ) {
    return await this.attendeesService.swapFields(body, adminId);
  }

  @Delete('/webinar')
  async deleteWebinarAttendees(
    @Id() adminId: string,
    @Body() body: DeleteWebinarAttendeesDTO,
  ) {
    if (!adminId) {
      throw new NotFoundException('Admin Id is Required');
    }
    const result = await this.attendeesService.hideAttendees(
      new Types.ObjectId(`${adminId}`),
      new Types.ObjectId(body.webinarId),
      body.attendees,
    );
    return {
      success: true,
      message: 'Webinar Attendees has been deleted Successfully.',
      data: result,
    };
  }

  @Delete('/all')
  async deleteAllAttendeeData(
    @Id() adminId: string,
    @Body() body: DeleteAllAttendeesDTO,
  ) {
    if (!adminId) {
      throw new NotFoundException('Admin Id is Required');
    }
    return await this.attendeesService.deleteAllAttendeeData(
      new Types.ObjectId(`${adminId}`),
      body.attendees,
    );
  }
}
