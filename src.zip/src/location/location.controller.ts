import {
  Body,
  Controller,
  Delete,
  Get,
  NotAcceptableException,
  Param,
  Patch,
  Post,
  Query,
  UnauthorizedException,
} from '@nestjs/common';
import {
  CreateLoationsDto,
  CreateLocationDto,
  UpdateLocationDto,
} from './dto/location.dto';
import { LocationService } from './location.service';
import { AdminId, Id, Role } from 'src/decorators/custom.decorator';
import { ConfigService } from '@nestjs/config';
import { Types } from 'mongoose';

@Controller('location')
export class LocationController {
  constructor(
    private readonly locationService: LocationService,
    private readonly configService: ConfigService,
  ) {}

  @Post()
  async addLocation(
    @Body() createLocationDto: CreateLocationDto,
    @Id() id: string,
    @AdminId() adminId: string,
    @Role() role: string,
  ): Promise<any> {
    console.log(createLocationDto);

    if (this.configService.get('appRoles').SUPER_ADMIN === role) {
      createLocationDto.isVerified = true;
      const result = await this.locationService.addLocation(createLocationDto);
      return result;
    } else if (this.configService.get('appRoles').ADMIN === role) {
      createLocationDto.isVerified = false;
      createLocationDto.isAdminVerified = true;
      createLocationDto.admin = id;
      const result = await this.locationService.addLocation(createLocationDto);

      //create notification

      return result;
    } else if (
      [
        this.configService.get('appRoles').EMPLOYEE_SALES,
        this.configService.get('appRoles').EMPLOYEE_REMINDER,
      ].includes(role)
    ) {
      createLocationDto.isVerified = false;
      createLocationDto.isAdminVerified = false;
      createLocationDto.admin = adminId;
      createLocationDto.employee = id;
      const result = await this.locationService.addLocation(createLocationDto);
      return result;
    } else {
      throw new UnauthorizedException(
        'Only Admin or Super admin are authorised to Add/Request locations',
      );
    }
  }

  @Get()
  async getLocations(
    @Query('page') qpage: string,
    @Query('limit') qlimit: string,
  ): Promise<any> {
    const page = parseInt(qpage) || 1;
    const limit = parseInt(qlimit) || 0;

    const result = await this.locationService.getLocations(page, limit);
    return result;
  }

  @Get('requests')
  async getLocationRequests(
    @Query('page') qpage: string,
    @Query('limit') qlimit: string,
    @Id() id: string,
    @Role() role: string,
  ): Promise<any> {
    const page = parseInt(qpage) || 1;
    const limit = parseInt(qlimit) || 10;

    if (role === this.configService.get('appRoles').SUPER_ADMIN) {
      const result = await this.locationService.getLocationRequests({
        page,
        limit,
        admin: null,
        isAdminVerified: true,
      });
      return result;
    } else if (this.configService.get('appRoles').ADMIN === role) {
      const result = await this.locationService.getLocationRequests({
        page,
        limit,
        admin: id,
      });
      return result;
    } else {
      return await this.locationService.getLocationRequests({
        page,
        limit,
        employee: id,
      });
    }
  }

  @Patch('/approve/:id')
  async approveLocation(
    @Body() updateLocationDto: UpdateLocationDto,
    @Param('id') id: string,
    @Role() role: string,
  ): Promise<any> {
    if (!id) throw new NotAcceptableException('Location ID not provided.');

    if (role === this.configService.get('appRoles').SUPER_ADMIN) {
      delete updateLocationDto.isAdminVerified;
      updateLocationDto.isVerified = true;
      const result = await this.locationService.approveRequest(
        id,
        updateLocationDto,
      );
      return result;
    } else if (this.configService.get('appRoles').ADMIN === role) {
      delete updateLocationDto.isVerified;
      delete updateLocationDto.name;
      updateLocationDto.isAdminVerified = true;
      const result = await this.locationService.approveRequest(
        id,
        updateLocationDto,
      );
      return result;
    } else {
      throw new UnauthorizedException(
        'Only Admin or Super admin are authorised to approve locations',
      );
    }
  }

  @Patch('/disapprove/:id')
  async disapproveLocation(
    @Body() updateLocationDto: UpdateLocationDto,
    @Param('id') id: string,
    @Role() role: string,
  ): Promise<any> {
    if (!id) throw new NotAcceptableException('Location ID not provided.');

    if (role === this.configService.get('appRoles').SUPER_ADMIN) {
      delete updateLocationDto.isAdminVerified;
      const result = await this.locationService.disapproveRequest(
        id,
        updateLocationDto,
      );
      return result;
    } else if (this.configService.get('appRoles').ADMIN === role) {
      delete updateLocationDto.isVerified;
      delete updateLocationDto.name;
      const result = await this.locationService.disapproveRequest(
        id,
        updateLocationDto,
      );
      return result;
    } else {
      throw new UnauthorizedException(
        'Only Admin or Super admin are authorised to disapprove locations',
      );
    }
  }

  @Patch('/update/:id')
  async updatelocation(
    @Body() updateLocationDto: { state: string; name: string },
    @Param('id') id: string,
  ): Promise<any> {
    return await this.locationService.updateLocation(
      new Types.ObjectId(id),
      updateLocationDto.state,
      updateLocationDto.name,
    );
  }

  @Post('import')
  async addLocations(@Body() data: CreateLoationsDto): Promise<any> {
    return await this.locationService.addLocations(data);
  }

  @Delete()
  async deleteLocations(@Body() data: { locationIds: string[] }): Promise<any> {
    if (!data.locationIds || data.locationIds.length === 0) {
      throw new NotAcceptableException('Location IDs not provided.');
    }
    const locationIds = data.locationIds.map((id) => new Types.ObjectId(id));
    return await this.locationService.deleteLocationById(locationIds);
  }
}
